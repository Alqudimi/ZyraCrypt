"""
Hybrid Post-Quantum Cryptography Engine

This module provides a production-grade hybrid cryptographic engine that combines
classical and post-quantum algorithms with proper key derivation and security.
"""

import os
from typing import Tuple, Optional, Dict, Any
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import x25519, ed25519
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305
from cryptography.hazmat.backends import default_backend
import time

# Import PQC components
from .pqc_cryptography import PQCKeyEncapsulation, PQCDigitalSignature, select_pqc_algorithms


class HybridKeyPair:
    """Container for hybrid classical and post-quantum key pairs."""
    
    def __init__(self, classical_private: bytes, classical_public: bytes,
                 pqc_private: bytes, pqc_public: bytes, 
                 classical_algo: str, pqc_algo: str):
        self.classical_private = classical_private
        self.classical_public = classical_public
        self.pqc_private = pqc_private
        self.pqc_public = pqc_public
        self.classical_algo = classical_algo
        self.pqc_algo = pqc_algo
        self.created_at = time.time()
    
    def get_public_keys(self) -> Dict[str, bytes]:
        """Get public key components for sharing."""
        return {
            'classical': self.classical_public,
            'pqc': self.pqc_public,
            'classical_algo': self.classical_algo.encode(),
            'pqc_algo': self.pqc_algo.encode()
        }


class HybridSharedSecret:
    """Container for hybrid shared secret with metadata."""
    
    def __init__(self, classical_secret: bytes, pqc_secret: bytes,
                 combined_secret: bytes, context: Dict[str, Any]):
        self.classical_secret = classical_secret
        self.pqc_secret = pqc_secret
        self.combined_secret = combined_secret
        self.context = context
        self.created_at = time.time()
    
    def derive_key(self, length: int, info: bytes, salt: Optional[bytes] = None) -> bytes:
        """Derive a key from the combined shared secret using HKDF."""
        if salt is None:
            salt = b''
        
        hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=length,
            salt=salt,
            info=info,
            backend=default_backend()
        )
        return hkdf.derive(self.combined_secret)
    
    def clear(self):
        """Securely clear secret material from memory."""
        # Zero out the secret bytes (best effort in Python)
        if hasattr(self.classical_secret, '__setitem__'):
            for i in range(len(self.classical_secret)):
                self.classical_secret[i] = 0
        if hasattr(self.pqc_secret, '__setitem__'):
            for i in range(len(self.pqc_secret)):
                self.pqc_secret[i] = 0
        if hasattr(self.combined_secret, '__setitem__'):
            for i in range(len(self.combined_secret)):
                self.combined_secret[i] = 0


class HybridPQCEngine:
    """
    Production-grade hybrid post-quantum cryptographic engine.
    
    This engine combines classical cryptography (X25519/Ed25519) with
    post-quantum algorithms (Kyber/Dilithium) using proper key derivation.
    """
    
    def __init__(self, security_level: str = "medium"):
        """
        Initialize the hybrid engine.
        
        Args:
            security_level: "low", "medium", or "high"
        """
        self.security_level = security_level
        self.pqc_kem_algo, self.pqc_sig_algo = select_pqc_algorithms(security_level)
        
        # Initialize PQC components
        self.pqc_kem = PQCKeyEncapsulation(self.pqc_kem_algo)
        self.pqc_sig = PQCDigitalSignature(self.pqc_sig_algo)
        
        # Algorithm identifiers for key derivation
        self.classical_kex_algo = "X25519"
        self.classical_sig_algo = "Ed25519"
        
    def generate_hybrid_keypair(self) -> HybridKeyPair:
        """Generate a hybrid classical and post-quantum key pair."""
        
        # Generate classical X25519 key pair
        classical_private_key = x25519.X25519PrivateKey.generate()
        classical_public_key = classical_private_key.public_key()
        
        classical_private_bytes = classical_private_key.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption()
        )
        
        classical_public_bytes = classical_public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )
        
        # Generate PQC key pair
        pqc_public_bytes, pqc_private_bytes = self.pqc_kem.generate_keypair()
        
        return HybridKeyPair(
            classical_private=classical_private_bytes,
            classical_public=classical_public_bytes,
            pqc_private=pqc_private_bytes,
            pqc_public=pqc_public_bytes,
            classical_algo=self.classical_kex_algo,
            pqc_algo=self.pqc_kem_algo
        )
    
    def generate_hybrid_signing_keypair(self) -> Tuple[Dict[str, bytes], Dict[str, bytes]]:
        """Generate hybrid signing key pairs for Ed25519 and Dilithium."""
        
        # Generate classical Ed25519 signing key pair
        ed25519_private = ed25519.Ed25519PrivateKey.generate()
        ed25519_public = ed25519_private.public_key()
        
        ed25519_private_bytes = ed25519_private.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption()
        )
        
        ed25519_public_bytes = ed25519_public.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )
        
        # Generate PQC signing key pair
        pqc_public_bytes, pqc_private_bytes = self.pqc_sig.generate_keypair()
        
        private_keys = {
            'classical': ed25519_private_bytes,
            'pqc': pqc_private_bytes,
            'classical_algo': self.classical_sig_algo.encode(),
            'pqc_algo': self.pqc_sig_algo.encode()
        }
        
        public_keys = {
            'classical': ed25519_public_bytes,
            'pqc': pqc_public_bytes,
            'classical_algo': self.classical_sig_algo.encode(),
            'pqc_algo': self.pqc_sig_algo.encode()
        }
        
        return private_keys, public_keys
    
    def derive_shared_secret(self, our_private_key: HybridKeyPair, 
                           peer_public_keys: Dict[str, bytes],
                           context: Optional[Dict[str, Any]] = None) -> HybridSharedSecret:
        """
        Derive a hybrid shared secret using both classical and PQC key exchange.
        
        Args:
            our_private_key: Our hybrid private key pair
            peer_public_keys: Peer's public keys (classical and PQC)
            context: Additional context for key derivation
            
        Returns:
            HybridSharedSecret with properly derived combined secret
        """
        if context is None:
            context = {}
        
        # Perform classical X25519 key exchange
        our_x25519_private = x25519.X25519PrivateKey.from_private_bytes(
            our_private_key.classical_private
        )
        peer_x25519_public = x25519.X25519PublicKey.from_public_bytes(
            peer_public_keys['classical']
        )
        classical_shared = our_x25519_private.exchange(peer_x25519_public)
        
        # Perform PQC key encapsulation
        pqc_ciphertext, pqc_shared = self.pqc_kem.encapsulate(peer_public_keys['pqc'])
        
        # Combine secrets using HKDF-Extract and HKDF-Expand with domain separation
        combined_secret = self._combine_secrets(
            classical_shared, pqc_shared, context,
            our_private_key.classical_public, peer_public_keys['classical']
        )
        
        # Store ciphertext in context for transmission
        context['pqc_ciphertext'] = pqc_ciphertext
        
        return HybridSharedSecret(
            classical_secret=classical_shared,
            pqc_secret=pqc_shared,
            combined_secret=combined_secret,
            context=context
        )
    
    def decapsulate_shared_secret(self, our_private_key: HybridKeyPair,
                                peer_public_key: bytes, pqc_ciphertext: bytes,
                                context: Optional[Dict[str, Any]] = None) -> HybridSharedSecret:
        """
        Decapsulate a hybrid shared secret on the recipient side.
        
        Args:
            our_private_key: Our hybrid private key pair
            peer_public_key: Peer's classical public key
            pqc_ciphertext: PQC encapsulated ciphertext
            context: Additional context for key derivation
            
        Returns:
            HybridSharedSecret with properly derived combined secret
        """
        if context is None:
            context = {}
        
        # Perform classical X25519 key exchange
        our_x25519_private = x25519.X25519PrivateKey.from_private_bytes(
            our_private_key.classical_private
        )
        peer_x25519_public = x25519.X25519PublicKey.from_public_bytes(peer_public_key)
        classical_shared = our_x25519_private.exchange(peer_x25519_public)
        
        # Perform PQC key decapsulation
        pqc_shared = self.pqc_kem.decapsulate(our_private_key.pqc_private, pqc_ciphertext)
        
        # Combine secrets using HKDF-Extract and HKDF-Expand with domain separation
        combined_secret = self._combine_secrets(
            classical_shared, pqc_shared, context,
            peer_public_key, our_private_key.classical_public
        )
        
        return HybridSharedSecret(
            classical_secret=classical_shared,
            pqc_secret=pqc_shared,
            combined_secret=combined_secret,
            context=context
        )
    
    def _combine_secrets(self, classical_secret: bytes, pqc_secret: bytes,
                        context: Dict[str, Any], sender_pubkey: bytes,
                        recipient_pubkey: bytes) -> bytes:
        """
        Combine classical and PQC secrets using HKDF with domain separation.
        
        This follows the recommendations from the architect for proper key derivation
        with domain-separated labels and context binding.
        """
        # Create salt from both secrets using HKDF-Extract
        extract_hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=32,
            salt=b'',
            info=b'HYBRID_PQC_EXTRACT',
            backend=default_backend()
        )
        
        # Concatenate both secrets for extraction
        combined_input = classical_secret + pqc_secret
        salt = extract_hkdf.derive(combined_input)
        
        # Create context string with domain separation
        context_parts = [
            b'HYBRID_PQC_ENGINE_V1',
            self.classical_kex_algo.encode(),
            self.pqc_kem_algo.encode(),
            sender_pubkey,
            recipient_pubkey,
            str(int(time.time())).encode()  # Timestamp for freshness
        ]
        
        # Add additional context if provided
        if context:
            context_json = str(context).encode()
            context_parts.append(context_json)
        
        info = b'||'.join(context_parts)
        
        # Derive final key using HKDF-Expand
        expand_hkdf = HKDF(
            algorithm=hashes.SHA256(),
            length=32,  # 256-bit key
            salt=salt,
            info=info,
            backend=default_backend()
        )
        
        return expand_hkdf.derive(combined_input)
    
    def hybrid_encrypt(self, plaintext: bytes, recipient_public_keys: Dict[str, bytes],
                      algorithm: str = "AES-256-GCM",
                      additional_data: Optional[bytes] = None) -> Tuple[Dict[str, bytes], bytes]:
        """
        Perform hybrid encryption with classical and PQC key exchange.
        
        Args:
            plaintext: Data to encrypt
            recipient_public_keys: Recipient's hybrid public keys
            algorithm: Symmetric encryption algorithm
            additional_data: Additional authenticated data
            
        Returns:
            Tuple of (key_exchange_data, ciphertext)
        """
        # Generate ephemeral key pair
        ephemeral_keypair = self.generate_hybrid_keypair()
        
        # Derive shared secret
        shared_secret = self.derive_shared_secret(ephemeral_keypair, recipient_public_keys)
        
        # Derive encryption key
        encryption_key = shared_secret.derive_key(32, b'HYBRID_PQC_ENCRYPTION')
        
        # Encrypt with chosen symmetric algorithm
        if algorithm == "AES-256-GCM":
            aead = AESGCM(encryption_key)
            nonce = os.urandom(12)
            ciphertext = aead.encrypt(nonce, plaintext, additional_data)
            ciphertext = nonce + ciphertext
        elif algorithm == "ChaCha20-Poly1305":
            aead = ChaCha20Poly1305(encryption_key)
            nonce = os.urandom(12)
            ciphertext = aead.encrypt(nonce, plaintext, additional_data)
            ciphertext = nonce + ciphertext
        else:
            raise ValueError(f"Unsupported algorithm: {algorithm}")
        
        # Prepare key exchange data for transmission
        key_exchange_data = {
            'ephemeral_classical': ephemeral_keypair.classical_public,
            'ephemeral_pqc': ephemeral_keypair.pqc_public,
            'pqc_ciphertext': shared_secret.context['pqc_ciphertext'],
            'algorithm': algorithm.encode(),
            'classical_algo': self.classical_kex_algo.encode(),
            'pqc_algo': self.pqc_kem_algo.encode()
        }
        
        # Clear sensitive data
        shared_secret.clear()
        
        return key_exchange_data, ciphertext
    
    def hybrid_decrypt(self, ciphertext: bytes, key_exchange_data: Dict[str, bytes],
                      our_private_key: HybridKeyPair,
                      additional_data: Optional[bytes] = None) -> bytes:
        """
        Perform hybrid decryption using stored private keys.
        
        Args:
            ciphertext: Encrypted data
            key_exchange_data: Key exchange information from encryption
            our_private_key: Our hybrid private key pair
            additional_data: Additional authenticated data
            
        Returns:
            Decrypted plaintext
        """
        # Extract key exchange components
        ephemeral_classical = key_exchange_data['ephemeral_classical']
        pqc_ciphertext = key_exchange_data['pqc_ciphertext']
        algorithm = key_exchange_data['algorithm'].decode()
        
        # Derive shared secret
        shared_secret = self.decapsulate_shared_secret(
            our_private_key, ephemeral_classical, pqc_ciphertext
        )
        
        # Derive decryption key
        decryption_key = shared_secret.derive_key(32, b'HYBRID_PQC_ENCRYPTION')
        
        # Decrypt with appropriate symmetric algorithm
        try:
            if algorithm == "AES-256-GCM":
                aead = AESGCM(decryption_key)
                nonce = ciphertext[:12]
                encrypted_data = ciphertext[12:]
                plaintext = aead.decrypt(nonce, encrypted_data, additional_data)
            elif algorithm == "ChaCha20-Poly1305":
                aead = ChaCha20Poly1305(decryption_key)
                nonce = ciphertext[:12]
                encrypted_data = ciphertext[12:]
                plaintext = aead.decrypt(nonce, encrypted_data, additional_data)
            else:
                raise ValueError(f"Unsupported algorithm: {algorithm}")
        finally:
            # Clear sensitive data
            shared_secret.clear()
        
        return plaintext
    
    def hybrid_sign(self, message: bytes, private_keys: Dict[str, bytes]) -> Dict[str, bytes]:
        """
        Create hybrid digital signatures using both classical and PQC algorithms.
        
        Args:
            message: Message to sign
            private_keys: Hybrid private keys (classical and PQC)
            
        Returns:
            Dictionary containing both signatures
        """
        # Classical Ed25519 signature
        ed25519_private = ed25519.Ed25519PrivateKey.from_private_bytes(
            private_keys['classical']
        )
        classical_signature = ed25519_private.sign(message)
        
        # PQC Dilithium signature
        pqc_signature = self.pqc_sig.sign(private_keys['pqc'], message)
        
        return {
            'classical': classical_signature,
            'pqc': pqc_signature,
            'message_hash': hashes.Hash(hashes.SHA256(), backend=default_backend()).finalize(),
            'classical_algo': self.classical_sig_algo.encode(),
            'pqc_algo': self.pqc_sig_algo.encode()
        }
    
    def hybrid_verify(self, message: bytes, signatures: Dict[str, bytes],
                     public_keys: Dict[str, bytes]) -> bool:
        """
        Verify hybrid digital signatures.
        
        Args:
            message: Original message
            signatures: Hybrid signatures to verify
            public_keys: Hybrid public keys
            
        Returns:
            True if both signatures are valid
        """
        try:
            # Verify classical Ed25519 signature
            ed25519_public = ed25519.Ed25519PublicKey.from_public_bytes(
                public_keys['classical']
            )
            ed25519_public.verify(signatures['classical'], message)
            classical_valid = True
        except Exception:
            classical_valid = False
        
        try:
            # Verify PQC Dilithium signature
            pqc_valid = self.pqc_sig.verify(
                public_keys['pqc'], message, signatures['pqc']
            )
        except Exception:
            pqc_valid = False
        
        # Both signatures must be valid for hybrid verification to pass
        return classical_valid and pqc_valid